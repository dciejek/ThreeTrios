package model;

import java.awt.*;

public enum PlayerColor {
  BLUE(Color.BLUE),
  RED(Color.RED);

  PlayerColor(Color color) {}
}
