package view;

import model.Card;

public interface ThreeTriosView<C extends Card> {

}
